import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_clyde/Final%20Project/contacts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_clyde/add_data.dart';
import 'package:flutter/material.dart';

class AllContactsData extends StatefulWidget {
  const AllContactsData({
    super.key,
  });

  @override
  State<AllContactsData> createState() => _AllContactsDataState();
}

class _AllContactsDataState extends State<AllContactsData> {
  Stream<List<Contacts>> readUsers() {
    return FirebaseFirestore.instance.collection('Contacts').snapshots().map(
          (snapshot) => snapshot.docs
              .map((doc) => Contacts.fromJson(doc.data()))
              .toList(),
        );
  }

  Widget buildList(Contacts contact) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.red,
        radius: 30,
        child: CircleAvatar(
          backgroundImage: NetworkImage(contact.image),
          radius: 25,
        ),
      ),
      title: Text(contact.name),
      subtitle: Text(contact.id),
      dense: true,
      onTap: () {},
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            onPressed: () {
              // Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => UpdateData(employee: employee),
              //   ),
              // );
            },
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(
            onPressed: () {
              // deleteUser(contact.id);
            },
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
    );
  }

  Future deleteUser(String id) async {
    final docUser = FirebaseFirestore.instance.collection('Contacts').doc(id);
    docUser.delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            FirebaseAuth.instance.signOut();
          },
          icon: const Icon(Icons.arrow_back_ios_new),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AddData(),
                ),
              );
            },
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: StreamBuilder<List<Contacts>>(
        builder: ((context, snapshot) {
          if (snapshot.hasError) {
            return Text('Something went wrong! ${snapshot.error}');
          } else if (snapshot.hasData) {
            final contacts = snapshot.data!;
            return ListView(
              children: contacts.map((buildList)).toList(),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        }),
        stream: readUsers(),
      ),
    );
  }
}
