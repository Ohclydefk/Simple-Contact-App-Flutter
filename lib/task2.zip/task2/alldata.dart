import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_clyde/add_data.dart';
import 'package:firebase_clyde/employee.dart';
import 'package:firebase_clyde/update_data.dart';
import 'package:flutter/material.dart';

class AllData extends StatefulWidget {
  const AllData({super.key});

  @override
  State<AllData> createState() => _AllDataState();
}

class _AllDataState extends State<AllData> {
  Stream<List<Employee>> readUsers() {
    return FirebaseFirestore.instance.collection('Employee').snapshots().map(
          (snapshot) => snapshot.docs
              .map((doc) => Employee.fromJson(doc.data()))
              .toList(),
        );
  }

  Widget buildList(Employee employee) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.red,
        radius: 30,
        child: CircleAvatar(
          backgroundImage: NetworkImage(employee.image),
          radius: 25,
        ),
      ),
      title: Text(employee.name),
      subtitle: Text(employee.email),
      dense: true,
      onTap: () {},
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => UpdateData(employee: employee),
                ),
              );
            },
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(
            onPressed: () {
              deleteUser(employee.id);
            },
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
    );
  }

  Future deleteUser(String id) async {
    final docUser = FirebaseFirestore.instance.collection('Employee').doc(id);
    docUser.delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('List of Firebase Data'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AddData(),
                ),
              );
            },
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: StreamBuilder<List<Employee>>(
        builder: ((context, snapshot) {
          if (snapshot.hasError) {
            return Text('Someting went wrong! ${snapshot.error}');
          } else if (snapshot.hasData) {
            final employee = snapshot.data!;
            return ListView(
              children: employee.map((buildList)).toList(),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        }),
        stream: readUsers(),
      ),
    );
  }
}
