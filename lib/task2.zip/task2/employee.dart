class Employee {
  final String email;
  final String name;
  final String id;
  final String image;
  Employee({
    required this.email,
    required this.name,
    required this.id,
    required this.image,
  });

  static Employee fromJson(Map<String, dynamic> json) => Employee(
        id: json['id'],
        email: json['email'],
        name: json['name'],
        image: json['image']
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'image': image,

      };
}
